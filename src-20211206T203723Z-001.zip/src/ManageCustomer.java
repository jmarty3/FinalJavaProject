import java.util.Scanner;

public class ManageCustomer {

	public static void main(String[] args) {
		
		String CustID;
		String Phone;
		String Fname;
		String Lname;
		Scanner input= new Scanner(System.in);
		
		//add customer
		System.out.print("Enter the Customer ID: ");
		CustID = input.next();
		System.out.print("Enter the Phone number: ");
		Phone = input.next();
		System.out.print("Enter the First Name: ");
		Fname = input.next();
		System.out.print("Enter the Last Name: ");
		Lname = input.next();

		//create Customer record
		Customer CustRec= new Customer(CustID,Phone,Fname,Lname);
		
		//display cust records
		System.out.println("Customer ID: " + CustRec.getCustID());
		System.out.println("Phone Number: " + CustRec.getPhone());
		System.out.println("First Name: " + CustRec.getFname());
		System.out.println("Last Name: " + CustRec.getLname());
	}

}
