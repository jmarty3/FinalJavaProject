
public class Magazines extends Publication {

	//private String ISBN;
	private String Title;
	private String Volume;
	private String Publisher;
	private String Issue;
	
	public Magazines(String isbn,String tl,String vol,String pub, String is) {
		setISBN(isbn);
		Title = tl;
		Volume =  vol;
		Publisher = pub;
		Issue = is;
		
	}
	
	public String getTitle() {
		return Title;
	}
	public String getVolume() {
		return Volume;
	}
	public String getPublisher() {
		return Publisher;
	}
	public String getIssue() {
		return Issue;
	}
	
	public void setTitle(String tl) {
		Title = tl;
	}
	public void setAuthor(String vol) {
		Volume = vol;
	}
	public void setPublisher(String pub) {
		Publisher = pub;
	}
	public void setYear(String is) {
		Issue = is;
	}
}

