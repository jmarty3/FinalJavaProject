import java.util.Scanner;

public class ManageMagazines {
	public static void main(String[] args) {
		
		String ISBN;
		String Title;
		String Volume;
		String Publisher;
		String Issue;
		Scanner input= new Scanner(System.in);
		
		//add customer
		// magazine info
		System.out.print("Enter the ISBN of book: ");
		ISBN = input.nextLine();
		System.out.print("Enter the Title of Magazine: ");
		Title = input.nextLine();
		System.out.print("Enter the Publisher: ");
		Publisher = input.nextLine();
		System.out.print("Enter the Volume number: ");
		//Publisher = input.nextLine();
		Volume = input.nextLine();
		//System.out.print("Enter the year it was published: ");
		//Year = input.next();
		//ADDED:
		System.out.print("Enter the Issue number: ");
		Issue = input.next();

		//create Book record
		//Books BookRec = new Books(Title,Author,Publisher,Year);
		Magazines MagRec = new Magazines(ISBN, Title,Volume,Publisher,Issue);
		
		//display book records
		System.out.println("ISBN: " + MagRec.getISBN());
		System.out.println("Book Title: " + MagRec.getTitle());
		System.out.println("Volume: " + MagRec.getVolume());
		System.out.println("Publisher: " + MagRec.getPublisher());
		System.out.println("Issue: " + MagRec.getIssue());
	}
}


