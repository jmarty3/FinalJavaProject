import java.util.Scanner;

public class ManageRentals {
	public static void main(String[] args) {
		String CustID;
		String ISBN;
		String DateRented;
		String DateDue;
		Scanner input= new Scanner(System.in);
		
		//add customer
		System.out.print("Enter Customer ID: ");
		CustID = input.next();
		System.out.print("Enter ISBN: ");
		ISBN = input.next();
		System.out.print("Enter Date rented: ");
		DateRented = input.next();
		System.out.print("Enter Date Due: ");
		DateDue = input.next();
		
	//create rental record
	rentals RentRec = new rentals(CustID,ISBN,DateRented,DateDue);
	
	//display Renatl records
	System.out.println("Customer ID: " + RentRec.getCustID());
	System.out.println("ISBN: " + RentRec.getISBN());
	System.out.println("Date Rented: " + RentRec.getDateRented());
	System.out.println("Date Due: " + RentRec.getDateDue());
}
}
