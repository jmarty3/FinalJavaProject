import java.util.Scanner;

public class rentals {

		String CustID;
		String ISBN;
		String DateRented;
		String DateDue;
		Scanner input= new Scanner(System.in);
		
		public rentals(String cust, String isbnNum, String rentDate, String dueDate) {
			CustID = cust;
			ISBN = isbnNum;
			DateRented = rentDate;
			DateDue = dueDate;
		}
		
		public String getCustID() {
			return CustID;
		}
		public String getISBN() {
			return ISBN;
		}
		public String getDateRented() {
			return DateRented;
		}
		public String getDateDue() {
			return DateDue;
		}
		
		public void setCustID(String cust) {
			CustID = cust;
		}
		public void setISBN(String isbnNum) {
			ISBN = isbnNum;
		}
		public void setDateRented(String rentDate) {
			DateRented = rentDate;
		}
		public void setDateDue(String dueDate) {
			DateDue = dueDate;
		}
		
}
