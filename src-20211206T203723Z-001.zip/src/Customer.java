
public class Customer {

	private String CustID;
	private String Phone;
	private String Fname;
	private String Lname;
	
	public Customer(String cust,String ph,String fn,String ln) {
		CustID = cust;
		Phone = ph;
		Fname = fn;
		Lname = ln;
	}
	
	public String getCustID() {
		return CustID;
	}
	public String getPhone() {
		return Phone;
	}
	public String getFname() {
		return Fname;
	}
	public String getLname() {
		return Lname;
	}
	
	public void setCustID(String cust) {
		CustID = cust;
	}
	public void setPhone(String ph) {
		Phone = ph;
	}
	public void setFname(String fn) {
		Fname = fn;
	}
	public void setLname(String ln) {
		Lname = ln;
	}
}
