import java.util.Scanner;

public class ManageBooks {
	public static void main(String[] args) {
		
		String ISBN;
		String Title;
		String Author;
		String Publisher;
		String Year;
		Scanner input= new Scanner(System.in);
		
		//add customer
		// add book info
		System.out.print("Enter the ISBN of book: ");
		ISBN = input.nextLine();
		System.out.print("Enter the Title of book: ");
		Title = input.nextLine();
		System.out.print("Enter the Author of that book: ");
		Author = input.nextLine();
		System.out.print("Enter the Publisher of that book: ");
		Publisher = input.nextLine();
		System.out.print("Enter the year it was published: ");
		Year = input.nextLine();

		//create Book record
		Books BookRec = new Books(ISBN, Title,Author,Publisher,Year);
		
		//display book records
		System.out.println("ISBN: " + BookRec.getISBN());
		System.out.println("Book Title: " + BookRec.getTitle());
		System.out.println("Author: " + BookRec.getAuthor());
		System.out.println("Publisher: " + BookRec.getPublisher());
		System.out.println("Year: " + BookRec.getYear());
	}
}


// out- show books rented out/ books show available books

