
public abstract class Publication {
	private String ISBN;
	
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String i) {
		ISBN = i;
	}
}
