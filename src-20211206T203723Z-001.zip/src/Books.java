
public class Books extends Publication {
	
	//private String ISBN;
	private String Title;
	private String Author;
	private String Publisher;
	private String Year;
	
	public Books(String isbn,String tl,String auth,String pub, String yr) {
		setISBN(isbn);
		Title = tl;
		Author = auth;
		Publisher = pub;
		Year = yr;
		
	}
	
	public String getTitle() {
		return Title;
	}
	public String getAuthor() {
		return Author;
	}
	public String getPublisher() {
		return Publisher;
	}
	public String getYear() {
		return Year;
	}
	
	public void setTitle(String tl) {
		Title = tl;
	}
	public void setAuthor(String auth) {
		Author = auth;
	}
	public void setPublisher(String pub) {
		Publisher = pub;
	}
	public void setYear(String yr) {
		Year = yr;
	}
}
